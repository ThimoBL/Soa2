﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Sprints.Factory
{
    public enum SprintType
    {
        Release = 0,
        Review = 1
    }
}
